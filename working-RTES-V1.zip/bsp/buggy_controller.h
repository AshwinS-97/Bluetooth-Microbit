


int init_controller(void);
void check_controllerMsg(void );
void add_controllerMsg(char* command);
void execute_driver(char* command);
void task_log(void *args);
void task_stop_log(void);
void task_stop(void);


