#ifndef CONTROL_H
#define CONTROL_H
#include <stdint.h>

void move(char direction, int speed);

#endif  /* CONTROL_H */